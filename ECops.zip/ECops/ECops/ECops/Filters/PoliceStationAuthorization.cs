﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ECops.Filters
{
    public class PoliceStationAuthorization : ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);
            bool logstatus = Convert.ToBoolean(filterContext.HttpContext.Session["logstatus"]);
            if (logstatus == false)
            {
                filterContext.Controller.TempData["authFlag"] = "0";
                filterContext.Controller.TempData["authMessage"] = "Sorry you are not logged on..!!";
                filterContext.Result = new RedirectResult("~/Account/SignIn");
            }
            else
            {
                var rolename = filterContext.HttpContext.Session["rolename"].ToString();
                if (rolename != "PoliceStation")
                {
                    filterContext.Controller.TempData["authFlag"] = "0";
                    filterContext.Controller.TempData["authMessage"] = "Sorry you are not authorize to View this Page..!!";
                    filterContext.Result = new RedirectResult("~/Account/SignIn");
                }
                else
                {
                    filterContext.HttpContext.Response.Cache.SetCacheability(HttpCacheability.NoCache);
                    filterContext.HttpContext.Response.Cache.SetExpires(DateTime.UtcNow.AddHours(-1));
                    filterContext.HttpContext.Response.Cache.SetNoStore();
                }
            }
        }
    }
}