﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class ComplaintModel
    {
        #region Data Members

        [Required]
        public int ComplaintNo { get; set; }

        [Required(ErrorMessage = "Plz Select Complaint Type..!!")]
        public string ComplaintType { get; set; }

        [Required(ErrorMessage = "Plz Select Complaint Detail..!!")]
        [DataType(DataType.MultilineText)]
        public string ComplaintDetail { get; set; }

        [Required]
        public DateTime ComplaintDate { get; set; }

        [Required]
        public string CUsername { get; set; }

        [Required(ErrorMessage = "Plz Select State")]
        public int StateId { get; set; }

        [Required(ErrorMessage = "Plz Select City")]
        public int CityId { get; set; }

        [Required(ErrorMessage = "Plz Select Police Station")]
        public string PSUsername { get; set; }

        [Required]
        public string Status { get; set; }

        public string ActionTaken { get; set; }

        public List<System.Web.Mvc.SelectListItem> LstComplaintTypes { get; set; }

        #endregion

        #region Shared Methods

        public static dynamic GetComplaints()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select complaintno,complainttype,complaintdesc,complaintdate,statename,cityname,co.PSUsername," +
                                "ps.PSName as PSName, ps.Address as PSAddress, ps.PinCode as PSPincode," +
                                "ps.ContactNos as PSContactNo, ps.Email as PSEmail, ps.PSInchargeName," +
                                "ps.InchargeContactNo, ci.Name as CName, ci.Address as CAddress, " +
                                "ci.ContactNo as CContactNo, ci.Email as CEmail,co.Status,co.ActionTaken from complaints co " +
                                "inner join states st on co.StateId = st.StateId inner join cities c " +
                                "on co.CityId = c.CityId inner join policestations ps on co.PSUsername = ps.PSUsername " +
                                "inner join citizens ci on co.cusername = ci.cusername order by complaintno desc");
            db.Close();
            return rows;
        }

        public static dynamic GetUserWiseComplaints(string cusername)
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select complaintno,complainttype,complaintdesc,complaintdate,ps.PSName," +
                                "statename, cityname, status,ActionTaken from complaints co inner " +
                                "join states s on co.StateId = s.StateId inner join cities c " +
                                "on co.CityId = c.cityid inner join policestations ps on " +
                                "co.PSUsername = ps.PSUsername where CUsername = @0 " +
                                "order by complaintno desc", cusername);
            db.Close();
            return rows;
        }
        public static void LodgeComplaint(ComplaintModel cm)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("insert into Complaints values(@0,@1,@2,@3,@4,@5,@6,@7,@8,@9)", cm.ComplaintNo, cm.ComplaintType, cm.ComplaintDetail, cm.ComplaintDate, cm.CUsername, cm.StateId, cm.CityId, cm.PSUsername, cm.ActionTaken, cm.Status);
            db.Close();
        }

        public static void UpdateComplaint(string complaintno, string status, string action)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("update Complaints set Status=@1,ActionTaken=@2 where ComplaintNo=@0", complaintno, status, action);
            db.Close();
        }


        public static void DeleteComplaint(int complaintno)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from Complaints where complaintno=@0", complaintno);
            db.Close();
        }



        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(complaintno) from complaints");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}