﻿using System.ComponentModel.DataAnnotations;

namespace ECops.Models.ViewModels
{
    public class ChangePasswordModel
    {
        #region Data Members

        [Required]
        public string Username { get; set; }

        [Required(ErrorMessage = "Plz Enter Password")]
        [DataType(DataType.Password)]
        public string OldPassword { get; set; }

        [Required(ErrorMessage = "Plz Enter New Password")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }

        [Required(ErrorMessage = "Plz Enter Confirm Password")]
        [DataType(DataType.Password)]
        [Compare("NewPassword", ErrorMessage = "Password does not match")]
        public string ConfirmPassword { get; set; }

        #endregion
    }
}