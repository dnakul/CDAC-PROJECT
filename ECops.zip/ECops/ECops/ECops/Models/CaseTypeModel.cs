﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class CaseTypeModel
    {
        #region Data Members

        [Required]
        public int CaseTypeId { get; set; }

        [Required(ErrorMessage = "Enter Case Type Detail..!!")]
        [StringLength(maximumLength:100,ErrorMessage = "Length should be atleast 10 characters",MinimumLength = 1)]
        public string CaseTypeDesc { get; set; }

        [Required]
        public bool Flag { get; set; }

        #endregion

        #region Shared Methods

        public static List<System.Web.Mvc.SelectListItem> GetCaseTypeList()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("Select * from CaseTypes");
            db.Close();
            var lst = new List<System.Web.Mvc.SelectListItem>();
            if (rows.Count() > 0)
            {
                foreach (var row in rows) {
                    System.Web.Mvc.SelectListItem li = new System.Web.Mvc.SelectListItem();
                    li.Text = row.casetypedesc;
                    li.Value = row.casetypeid.ToString();
                    lst.Add(li);
                }
            }
            return lst;
        }

        public static dynamic GetCaseTypes()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from casetypes order by casetypeid desc");
            db.Close();
            return rows;
        }

        public static void Save(CaseTypeModel ct)
        {
            var query = "update casetypes set casetypedesc=@1 where casetypeid=@0";
            if (ct.Flag == true)
                query = "insert into casetypes values(@0,@1)";
            var db = Database.Open("LocalSqlServer");
            db.Execute(query, ct.CaseTypeId, ct.CaseTypeDesc);
            db.Close();
        }

        public static void Delete(int ctid)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from CaseTypes where CaseTypeId=@0", ctid);
            db.Close();
        }

        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(CaseTypeId) from CaseTypes");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}