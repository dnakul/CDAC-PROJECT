﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class StateModel
    {
        #region Data Members

        [Required]
        public int StateId { get; set; }

        [Required(ErrorMessage = "Plz Enter State Name..!!")]
        public string StateName { get; set; }

        [Required]
        public bool Flag { get; set; }

        #endregion

        #region Shared Methods

        public static dynamic GetStates()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from states order by StateId desc");
            db.Close();
            return rows;
        }

        public static void Save(StateModel st)
        {
            var query = "update states set statename=@1 where stateid=@0";
            if (st.Flag == true)
                query = "insert into states values(@0,@1)";
            var db = Database.Open("LocalSqlServer");
            db.Execute(query, st.StateId,st.StateName);
            db.Close();
        }

        public static void Delete(int stid)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from States where StateId=@0", stid);
            db.Close();
        }

        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(StateId) from States");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}