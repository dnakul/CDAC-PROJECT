﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class CitizenModel
    {
        #region Data Members

        [Required(ErrorMessage="Plz Enter Username")]
        [StringLength(maximumLength:12,ErrorMessage="Username should be atleast six characters",MinimumLength = 6)]
        public string CUsername { get; set; }

        [Required(ErrorMessage = "Plz Enter Password..!!")]
        [DataType(DataType.Password)]
        [StringLength(maximumLength: 50, ErrorMessage = "Password should be atleast 6 characters", MinimumLength = 6)]
        public string Password { get; set; }

        [Required]
        public string Rolename { get; set; }

        [Required(ErrorMessage = "Plz Enter Confirm Password")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Password does not match")]
        public string ConfirmPassword { get; set; }

        [Required(ErrorMessage = "Plz Enter Name")]
        [StringLength(maximumLength: 50, ErrorMessage = "Name should be atleast six characters", MinimumLength = 6)]
        public string Name { get; set; }
        
        [Required]
        public string Gender { get; set; }
        
        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime DOB { get; set; }

        [Required(ErrorMessage ="Plz Select State")]
        public int StateId { get; set; }

        [Required(ErrorMessage = "Plz Select City")]
        public int CityId { get; set; }

        [Required(ErrorMessage = "Plz Enter Address")]
        [DataType(DataType.MultilineText)]
        public string Address { get; set; }

        [Required(ErrorMessage = "Plz Enter Pincode")]
        [StringLength(maximumLength: 10, ErrorMessage = "Pincode should be atleast five characters", MinimumLength = 5)]
        public string PinCode { get; set; }

        [Required(ErrorMessage = "Plz Enter Contact No")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(maximumLength: 15, ErrorMessage = "Contact Number should be minimum 10 and maximum 15 digits..", MinimumLength = 10)]
        public string ContactNo { get; set; }

        [Required(ErrorMessage = "Plz Enter Email")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required]
        public string IdProof { get; set; }

        [Required]
        public DateTime RegDate { get; set; }

        #endregion

        #region Shared Methods

        public static dynamic GetCitizens()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from Citizens order by RegDate desc");
            db.Close();
            return rows;
        }

        public static dynamic GetCitizenDetail(string cuname)
        {
            var db = Database.Open("LocalSqlServer");
            var row = db.QuerySingle("select * from Citizens where cusername=@0", cuname);
            db.Close();
            return row;
        }

        public static CitizenModel GetCitizen(string cuname)
        {
            var row = GetCitizenDetail(cuname);
            CitizenModel c = null;
            if (row != null) {
                c = new CitizenModel {
                    CUsername = row.cusername,
                    Name = row.Name,
                    Gender=row.Gender,
                    DOB=row.DOB,
                    StateId=row.stateid,
                    CityId=row.cityid,
                    Address=row.Address,
                    PinCode=row.PinCode,
                    ContactNo=row.ContactNo,
                    Email=row.Email,
                    IdProof=row.IdProof,
                    RegDate=row.RegDate
                };
            }

            return c;
        }

        public static void NewCitizen(CitizenModel cm) {
            var db = Database.Open("LocalSqlServer");
            db.Execute("insert into Users values(@0,@1,@2)",cm.CUsername,cm.Password,cm.Rolename);
            db.Execute("insert into Citizens values(@0,@1,@2,@3,@4,@5,@6,@7,@8,@9,@10,@11)", cm.CUsername,cm.Name,cm.Gender,cm.DOB,cm.StateId,cm.CityId,cm.Address,cm.PinCode,cm.ContactNo,cm.Email,cm.IdProof,cm.RegDate);
            db.Close();
        }

        public static void UpdateCitizen(CitizenModel cm)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("update Citizens set Name=@1,Gender=@2,DOB=@3,StateId=@4,CityId=@5,Address=@6,PinCode=@7,ContactNo=@8,Email=@9,IdProof=@10 where CUsername=@0", cm.CUsername, cm.Name, cm.Gender, cm.DOB, cm.StateId, cm.CityId, cm.Address, cm.PinCode, cm.ContactNo, cm.Email, cm.IdProof);
            db.Close();
        }

        public static void DeleteCitizen(string cusername)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from Citizens where CUsername=@0", cusername);
            db.Execute("Delete from users where Username=@0", cusername);
            db.Close();
        }



        #endregion
    }
}