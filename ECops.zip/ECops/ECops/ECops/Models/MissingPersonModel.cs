﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class MissingPersonModel
    {

        #region Data Members

        [Required]
        public int MPId { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Name")]
        public string MPName { get; set; }

        [Required]
        public string Gender { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Age in years")]
        public string Age { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Weight")]
        public string Weight { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Height")]
        public string Height { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Color")]
        public string Color { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Complexion")]
        public string Complexion { get; set; }

        [Required]
        public string Photo { get; set; }

        [Required(ErrorMessage = "Plz Enter Address")]
        [StringLength(maximumLength: 100, ErrorMessage = "Address should be atleast 5 digit Length", MinimumLength = 5)]
        [DataType(DataType.MultilineText)]
        public string Address { get; set; }

        [Required(ErrorMessage = "Plz Enter Pincode")]
        [StringLength(maximumLength: 15, ErrorMessage = "Pincode should be atleast 5 digit Number", MinimumLength = 5)]
        [DataType(DataType.PostalCode)]
        public string PinCode { get; set; }

        [Required(ErrorMessage = "Plz Enter Contact Person Name")]
        public string ContactPersonName { get; set; }

        [Required(ErrorMessage = "Plz Enter Contact Person No")]
        [StringLength(maximumLength: 20, ErrorMessage = "Contact Number should be atleast 10 digit Number", MinimumLength = 10)]
        [DataType(DataType.PhoneNumber)]
        public string ContactPersonNo { get; set; }

        [Required]
        public string PSUsername { get; set; }

        [Required]
        public bool Flag { get; set; }


        #endregion

        #region Shared Methods

        public static dynamic GetMissingPersons()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from missingpersons");
            db.Close();
            return rows;
        }

        public static dynamic GetMissingPersons(string psusername)
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from missingpersons where PSUsername=@0",psusername);
            db.Close();
            return rows;
        }

        public static void Save(MissingPersonModel mp)
        {
            var query = "update MissingPersons set mpname=@1,gender=@2,age=@3,weight=@4,height=@5,color=@6,complexion=@7,photo=@8,address=@9,pincode=@10,contactpersonname=@11,contactpersonno=@12,psusername=@13 where mpid=@0";
            if (mp.Flag == true)
                query = "insert into MissingPersons values(@0,@1,@2,@3,@4,@5,@6,@7,@8,@9,@10,@11,@12,@13)";
            var db = Database.Open("LocalSqlServer");
            db.Execute(query, mp.MPId, mp.MPName, mp.Gender, mp.Age, mp.Weight, mp.Height, mp.Color, mp.Complexion, mp.Photo, mp.Address, mp.PinCode, mp.ContactPersonName, mp.ContactPersonNo, mp.PSUsername);
            db.Close();
        }

        public static void Delete(int mpid)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from MissingPersons where MPId=@0", mpid);
            db.Close();
        }

        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(MPId) from MissingPersons");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}