﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class MostWantedPersonModel
    {

        #region Data Members

        [Required]
        public int MWId { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Name")]
        public string MWName { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Location")]
        public string MWLocation { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Offences")]
        public string MWOffences { get; set; }

        [Required(ErrorMessage = "Plz Enter Person Detail")]
        [DataType(DataType.MultilineText)]
        public string MWDesc { get; set; }

        [Required]
        public string MWPhoto { get; set; }

        [Required]
        public string PSUsername { get; set; }

        [Required]
        public bool Flag { get; set; }

        #endregion

        #region Shared Methods

        public static dynamic GetMostWantedPersons()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from MostwantedPersons");
            db.Close();
            return rows;
        }

        public static dynamic GetMostWantedPersons(string psuname)
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from MostwantedPersons where PSUsername=@0",psuname);
            db.Close();
            return rows;
        }

        public static void Save(MostWantedPersonModel mw)
        {
            var query = "update MostWantedPersons set mwname=@1,mwlocation=@2,mwoffences=@3,mwdesc=@4,mwphoto=@5,psusername=@6 where mwid=@0";
            if (mw.Flag == true)
                query = "insert into MostWantedPersons values(@0,@1,@2,@3,@4,@5,@6)";
            var db = Database.Open("LocalSqlServer");
            db.Execute(query, mw.MWId, mw.MWName, mw.MWLocation, mw.MWOffences, mw.MWDesc, mw.MWPhoto, mw.PSUsername);
            db.Close();
        }

        public static void Delete(int mwid)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from MostWantedPersons where MWId=@0", mwid);
            db.Close();
        }

        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(MWId) from MostWantedPersons");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}