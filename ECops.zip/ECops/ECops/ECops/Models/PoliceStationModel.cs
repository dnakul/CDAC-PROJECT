﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class PoliceStationModel
    {

        #region Data Members

        [Required(ErrorMessage = "Plz Enter Username")]
        [StringLength(maximumLength: 50, ErrorMessage = "Username should be atleast six characters", MinimumLength = 6)]
        public string PSUsername { get; set; }

        [Required(ErrorMessage = "Plz Enter Password..!!")]
        [DataType(DataType.Password)]
        [StringLength(maximumLength: 50, ErrorMessage = "Password should be atleast 6 characters", MinimumLength = 6)]
        public string Password { get; set; }


        [Required(ErrorMessage = "Plz Enter Confirm Password")]
        [DataType(DataType.Password)]
        [Compare("Password", ErrorMessage = "Password does not match")]
        public string ConfirmPassword { get; set; }

        [Required]
        public string Rolename { get; set; }


        [Required(ErrorMessage = "Plz Enter Name")]
        [StringLength(maximumLength: 50, ErrorMessage = "Name should be atleast six characters", MinimumLength = 6)]
        public string Name { get; set; }
                
        [Required(ErrorMessage = "Plz Select State")]
        public int StateId { get; set; }

        [Required(ErrorMessage = "Plz Select City")]
        public int CityId { get; set; }

        [Required(ErrorMessage = "Plz Enter Address")]
        [DataType(DataType.MultilineText)]
        public string Address { get; set; }

        [Required(ErrorMessage = "Plz Enter Pincode")]
        [StringLength(maximumLength: 10, ErrorMessage = "Pincode should be atleast five characters", MinimumLength = 5)]
        public string PinCode { get; set; }

        [Required(ErrorMessage = "Plz Enter Contact No")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(maximumLength: 20, ErrorMessage = "Contact Number should be minimum 10 and maximum 15 digits..", MinimumLength = 10)]
        public string ContactNos { get; set; }

        [Required(ErrorMessage = "Plz Enter Email")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }


        [Required(ErrorMessage = "Plz Enter Thana Incharge Name")]
        [StringLength(maximumLength: 50, ErrorMessage = "Name should be atleast six characters", MinimumLength = 6)]
        public string PSInchargeName { get; set; }

        [Required]        
        public string InchargeGender { get; set; }

        [Required(ErrorMessage = "Plz Enter Thana Incharge Contact No")]
        [DataType(DataType.PhoneNumber)]
        [StringLength(maximumLength: 15, ErrorMessage = "Contact Number should be minimum 10 and maximum 15 digits..", MinimumLength = 10)]
        public string InchargeContactNo { get; set; }

        [Required]
        public DateTime RegDate { get; set; }

        #endregion

        #region Shared Methods
                
        public static dynamic GetPoliceStationsList()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from policestations order by RegDate desc");
            db.Close();
            return rows;
        }


        public static dynamic GetPoliceStationDetail(string psuname)
        {
            var db = Database.Open("LocalSqlServer");
            var row = db.QuerySingle("select PSName,Address+', '+statename+', '+cityname+' - '+PinCode as Address,Email,ContactNos from policestations ps " +
                                "inner join States s on ps.stateid = s.stateid inner join cities c on ps.cityid = c.cityid " +
                                "where psusername = @0", psuname);
            db.Close();
            return row;
        }


        public static PoliceStationModel GetPoliceStation(string psuname)
        {
            var db = Database.Open("LocalSqlServer");
            var row = db.QuerySingle("select * from policestations where psusername = @0", psuname);
            db.Close();

            PoliceStationModel p=null;
            if (row != null)
            {
                p = new PoliceStationModel
                {
                    PSUsername = row.PSUsername,
                    Name = row.Name,                    
                    StateId = row.stateid,
                    CityId = row.cityid,
                    Address = row.Address,
                    PinCode = row.PinCode,
                    ContactNos = row.ContactNos,
                    Email = row.Email,
                    PSInchargeName = row.PSInchargeName,
                    InchargeGender = row.InchargeGender,
                    InchargeContactNo = row.InchargeContactNo,
                    RegDate = row.RegDate
                };
            }

            return p;
        }

        public static void NewPoliceStation(PoliceStationModel pm)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("insert into Users values(@0,@1,@2)", pm.PSUsername, pm.Password, pm.Rolename);
            db.Execute("insert into PoliceStations values(@0,@1,@2,@3,@4,@5,@6,@7,@8,@9,@10,@11)", pm.PSUsername, pm.Name, pm.StateId, pm.CityId, pm.Address, pm.PinCode, pm.ContactNos, pm.Email, pm.PSInchargeName, pm.InchargeGender, pm.InchargeContactNo, pm.RegDate);
            db.Close();
        }

        public static void UpdatePoliceStations(PoliceStationModel pm)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("update PoliceStations set Name=@1,StateId=@2,CityId=@3,Address=@4,PinCode=@5,ContactNos=@6,Email=@7,PSInchargeName=@8,InchargeGender=@9,InchargeContactNo=@10 where PSUsername=@0",pm.PSUsername, pm.Name, pm.StateId, pm.CityId, pm.Address, pm.PinCode, pm.ContactNos, pm.Email, pm.PSInchargeName, pm.InchargeGender, pm.InchargeContactNo);
            db.Close();
        }

        public static void DeletePoliceStation(string psusername)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from PoliceStations where PSUsername=@0", psusername);
            db.Execute("Delete from users where Username=@0", psusername);
            db.Close();
        }

        #endregion
    }
}