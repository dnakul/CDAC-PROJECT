﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class CityModel
    {
        #region Data Members        

        [Required]
        public int CityId { get; set; }

        [Required(ErrorMessage = "Plz Enter City Name..!!")]
        public string CityName { get; set; }

        [Required]
        public int StateId { get; set; }

        [Required]
        public bool Flag { get; set; }

        #endregion

        #region Shared Methods

        public static dynamic GetCities()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from cities order by cityid desc");
            db.Close();
            return rows;
        }

        public static void Save(CityModel cm)
        {
            var query = "update Cities set CityName=@1 where CityId=@0 and StateId=@2";
            if (cm.Flag == true)
                query = "insert into cities values(@0,@1,@2)";
            var db = Database.Open("LocalSqlServer");
            db.Execute(query, cm.CityId, cm.CityName,cm.StateId);
            db.Close();
        }

        public static void Delete(int cid)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from Cities where CityId=@0", cid);
            db.Close();
        }

        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(CityId) from Cities");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}