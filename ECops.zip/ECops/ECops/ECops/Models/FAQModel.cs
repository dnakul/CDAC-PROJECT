﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class FAQModel
    {
        #region Data Members

        [Required]
        public int FAQId { get; set; }

        [Required(ErrorMessage = "Plz Enter Question..!!")]
        [DataType(DataType.MultilineText)]
        public string Question { get; set; }

        [Required(ErrorMessage = "Plz Enter Answer..!!")]
        
        [DataType(DataType.MultilineText)]
        public string Answer { get; set; }

        [Required]
        public bool Flag { get; set; }

        #endregion

        #region Shared Methods

        public static dynamic GetFAQs()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from faqs order by faqid desc");
            db.Close();
            return rows;
        }

        public static void Save(FAQModel f)
        {
            var query = "update faqs set question=@1,answer=@2 where faqid=@0";
            if (f.Flag == true)
                query = "insert into faqs values(@0,@1,@2)";
            var db = Database.Open("LocalSqlServer");
            db.Execute(query, f.FAQId, f.Question, f.Answer);
            db.Close();
        }

        public static void Delete(int fid)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from faqs where faqId=@0", fid);
            db.Close();
        }

        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(FAQId) from FAQs");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}