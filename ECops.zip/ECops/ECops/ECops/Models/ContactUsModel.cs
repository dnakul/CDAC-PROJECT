﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class ContactUsModel
    {
        #region Data Members

        [Required]
        public int CUId { get; set; }

        [Required(ErrorMessage ="Plz Enter your Name..!!")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Plz Enter City..!!")]
        public string City { get; set; }

        [Required(ErrorMessage = "Plz Enter your Mobile No..!!")]
        [DataType(DataType.PhoneNumber)]
        public string Mobile { get; set; }

        [Required(ErrorMessage = "Plz Enter your Email Id..!!")]
        [DataType(DataType.EmailAddress)]
        public string Email { get; set; }

        [Required(ErrorMessage = "Plz Enter your Query..!!")]   
        [DataType(DataType.MultilineText)]
        public string Query { get; set; }

        [Required]
        public DateTime CUDate { get; set; }

        #endregion

        #region Shared Methods


        public static dynamic GetContactUsList()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from contactus order by cuid desc");
            db.Close();
            return rows;
        }


        public static void Save(ContactUsModel cu)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("insert into contactus values(@0,@1,@2,@3,@4,@5,@6)", cu.CUId, cu.Name, cu.City, cu.Mobile, cu.Email, cu.Query, cu.CUDate);
            db.Close();
        }

        public static void Delete(int cuid)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from ContactUs where CUId=@0", cuid);
            db.Close();
        }

        public static int GetMaxCUId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(cuid) from contactus");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}