﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class ImportantLinksModel
    {
        #region Shared Methods

        public static dynamic GetImportantLinks()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from ImportantLinks");
            db.Close();
            return rows;
        }

        #endregion
    }
}