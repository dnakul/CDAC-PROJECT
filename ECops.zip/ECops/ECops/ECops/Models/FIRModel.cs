﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class FIRModel
    {
        #region Data Members

        [Required]
        public int FIRNo { get; set; }

        [Required]
        public DateTime FIRDate { get; set; }

        [Required]
        public string CUsername { get; set; }

        [Required(ErrorMessage = "Plz Select Police Station")]
        public string PSUsername { get; set; }


        [Required(ErrorMessage = "Plz Enter Victim Name")]
        [StringLength(maximumLength: 50, ErrorMessage = "Victim Name should be atleast six characters", MinimumLength = 6)]
        public string VictimName { get; set; }

        [Required(ErrorMessage = "Plz Enter Victim Father Name")]
        [StringLength(maximumLength: 50, ErrorMessage = "Victim Father Name should be atleast six characters", MinimumLength = 6)]
        public string VictimFatherName { get; set; }

        [Required]
        public string VictimGender { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime VictimDOB { get; set; }

        [Required(ErrorMessage = "Plz Select State")]
        public int StateId { get; set; }

        [Required(ErrorMessage = "Plz Select City")]
        public int CityId { get; set; }

        [Required(ErrorMessage = "Plz Enter Address")]
        [DataType(DataType.MultilineText)]
        public string VictimAddress { get; set; }

        [Required(ErrorMessage = "Plz Enter Pincode")]
        [StringLength(maximumLength: 10, ErrorMessage = "Pincode should be atleast five characters", MinimumLength = 5)]
        public string VictimPinCode { get; set; }

        [Required(ErrorMessage = "Plz Select Case Type")]
        public int CaseTypeId { get; set; }

        public List<System.Web.Mvc.SelectListItem> LstCaseTypes { get; set; }

        [Required]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime CaseDate { get; set; }


        [Required(ErrorMessage = "Plz Enter Case Title")]
        [StringLength(maximumLength: 100, ErrorMessage = "Case Title should be atleast six characters", MinimumLength = 6)]
        public string CaseTitle { get; set; }

        [Required(ErrorMessage = "Plz Enter Case Detail")]
        [DataType(DataType.MultilineText)]
        public string CaseDesc { get; set; }

        [Required]
        public string FIRStatus { get; set; }

        public string ActionTaken { get; set; }



        #endregion

        #region Shared Methods

        public static dynamic GetFIRS()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select firno,firdate,casetypedesc,casetitle,casedesc," +
                                "casedate,victimname, victimfathername, victimgender, " +
                                "victimdob, victimaddress, statename, cityname, victimpincode, " +
                                "firstatus, ActionTaken, ci.Name, ci.ContactNo, ci.Email,f.PSUsername,ps.PSName as PSName," +
                                "ps.Address as PSAddress,ps.PinCode as PSPincode from firs f inner join casetypes ct on " +
                                "f.casetypeid = ct.casetypeid inner join states s on f.StateId = s.StateId " +
                                "inner join cities c on f.CityId = c.cityid inner join citizens ci on " +
                                "f.firusername = ci.cusername inner join policestations ps " +
                                "on f.PSUsername=ps.PSUsername order by firno desc");
            db.Close();
            return rows;
        }

        public static dynamic GetUserWiseFIRS(string cusername)
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select firno,firdate,casetypedesc,casetitle,casedesc,casedate," +
                                "victimname, victimfathername, victimgender, victimdob, victimaddress," +
                                "statename, cityname, victimpincode,firstatus,ActionTaken, ps.PSName as PSName," +
                                "ps.Address as PSAddress,ps.PinCode as PSPincode from firs f inner " +
                                "join casetypes ct on f.casetypeid = ct.casetypeid " +
                                "inner join states s on f.StateId = s.StateId inner join cities c " +
                                "on f.CityId = c.cityid inner join policestations ps on "+
                                "f.PSUsername=ps.PSUsername where firusername = @0 order by firno desc", cusername);
            db.Close();
            return rows;
        }

        public static dynamic GetPoliceStationWiseFIRS(string psusername)
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select firno,firdate,casetypedesc,casetitle,casedesc," +
                                "casedate,victimname, victimfathername, victimgender, " +
                                "victimdob, victimaddress, statename, cityname, victimpincode, " +
                                "firstatus, ActionTaken, ci.Name, ci.ContactNo, ci.Email from firs f "+
                                "inner join casetypes ct on f.casetypeid = ct.casetypeid inner join states s "+
                                "on f.StateId = s.StateId inner join cities c on f.CityId = c.cityid inner join "+
                                "citizens ci on f.firusername = ci.cusername where PSUsername = @0 " +
                                "order by firno desc", psusername);
            db.Close();
            return rows;
        }        

        public static void LodgeFIR(FIRModel fm)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("insert into FIRS values(@0,@1,@2,@3,@4,@5,@6,@7,@8,@9,@10,@11,@12,@13,@14,@15,@16,@17)", fm.FIRNo, fm.FIRDate, fm.CUsername, fm.PSUsername, fm.VictimName, fm.VictimFatherName, fm.VictimGender, fm.VictimDOB, fm.StateId, fm.CityId, fm.VictimAddress, fm.VictimPinCode, fm.CaseTypeId, fm.CaseDate, fm.CaseTitle, fm.CaseDesc, fm.FIRStatus, fm.ActionTaken);
            db.Close();
        }


        public static void DeleteFIR(int firno)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from FIRS where firno=@0", firno);
            db.Close();
        }

        public static void UpdateFIR(string firno,string status,string action)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("update FIRS set FIRStatus=@1,ActionTaken=@2 where FIRNo=@0", firno,status,action);
            db.Close();
        }

        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(firno) from firs");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}