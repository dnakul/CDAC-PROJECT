﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class NewsModel
    {
        #region Data Members

        [Required]
        public int NewsId { get; set; }

        [Required(ErrorMessage ="Plz Enter News Contents")]
        [DataType(DataType.MultilineText)]
        public string NewsContent { get; set; }

        [Required(ErrorMessage = "Plz Enter News Date")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:yyyy-MM-dd}", ApplyFormatInEditMode = true)]
        public DateTime NewsDate { get; set; }

        [Required]
        public bool Flag { get; set; }

        #endregion

        #region Shared Methods

        public static dynamic GetNews()
        {
            var db = Database.Open("LocalSqlServer");
            var rows = db.Query("select * from news order by newsid desc");
            db.Close();
            return rows;
        }

        public static void Save(NewsModel n)
        {
            var query = "update news set newscontent=@1,newsdate=@2 where newsid=@0";
            if (n.Flag == true)
                query = "insert into news values(@0,@1,@2)";
            var db = Database.Open("LocalSqlServer");
            db.Execute(query, n.NewsId,n.NewsContent,n.NewsDate);
            db.Close();
        }

        public static void Delete(int nid)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("delete from News where NewsId=@0", nid);
            db.Close();
        }

        public static int GetMaxId()
        {
            var db = Database.Open("LocalSqlServer");
            var obj = db.QueryValue("select max(NewsId) from News");
            db.Close();
            if (obj.ToString() == "")
                return 1;
            else
                return Convert.ToInt32(obj) + 1;
        }

        #endregion
    }
}