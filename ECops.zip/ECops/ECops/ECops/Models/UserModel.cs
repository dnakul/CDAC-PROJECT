﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using WebMatrix.Data;

namespace ECops.Models
{
    public class UserModel
    {
        #region Data Members
                
        [Required(ErrorMessage = "Plz Enter Username..!!")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Plz Enter Password..!!")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        [Required]
        public string Rolename { get; set; }

        #endregion

        #region Shared Methods

        public static bool Validate(UserModel user)
        {
            var db = Database.Open("LocalSqlServer");
            var cnt = db.QueryValue("select count(*) from Users where Username=@0 and Password=@1", user.Username, user.Password);
            db.Close();
            return (cnt == 1);
        }

        public static bool Validate(string username, string password)
        {
            var db = Database.Open("LocalSqlServer");
            var cnt = db.QueryValue("select count(*) from Users where Username=@0 and Password=@1", username, password);
            db.Close();
            return (cnt == 1);
        }

        public static string GetRoleName(string username)
        {
            var db = Database.Open("LocalSqlServer");
            var rolename = db.QueryValue("select Rolename from Users where Username=@0", username);
            db.Close();
            return rolename;
        }

        public static void UpdatePassword(string username, string oldpassword, string newpassword)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("update Users set Password=@2 where Username=@0 and Password=@1", username, oldpassword, newpassword);
            db.Close();
        }

        public static void CreateUser(UserModel user)
        {
            var db = Database.Open("LocalSqlServer");
            db.Execute("insert into users values(@0,@1,@2)", user.Username, user.Password, user.Rolename);
            db.Close();
        }

        #endregion

    }
}