﻿using ECops.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MySql.Data.MySqlClient;

namespace ECops.Controllers
{
    public class HomeController : Controller
    {
        // GET: Home
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Services()
        {
            return View();
        }

        public ActionResult NewsEvents()
        {
            return View(NewsModel.GetNews());
        }

        public ActionResult Faqs()
        {
            return View(FAQModel.GetFAQs());
        }

        public ActionResult ContactUs()
        {
            ContactUsModel cu = new ContactUsModel();
            cu.CUId = ContactUsModel.GetMaxCUId();
            cu.Name = "";
            cu.City = "";
            cu.Mobile = "";
            cu.Email = "";
            cu.Query = "";
            cu.CUDate = DateTime.Now;
            return View(cu);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult UpdateContactUs(ContactUsModel cu)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    ContactUsModel.Save(cu);
                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return Json(obj);
        }

        public ActionResult SafetyTipsforCitizens()
        {
            return View();
        }

        public ActionResult SafetyTipsforForeigners()
        {
            return View();
        }

        public ActionResult SafetyTipsforCyberCrime()
        {
            return View();
        }


        public ActionResult CityWisePoliceStations()
        {
            return View();
        }


        public ActionResult CityWiseImportantLinks()
        {
            return View();
        }

        public ActionResult MissingPersonsList()
        {
            return View();
        }

        public ActionResult MostWantedPersonsList()
        {
            return View();
        }


        

            


    }
}