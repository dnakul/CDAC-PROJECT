﻿using ECops.Filters;
using ECops.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ECops.Controllers
{
    public class PoliceStationController : Controller
    {
        // GET: PoliceStation
        [PoliceStationAuthorization]
        public ActionResult Index()
        {
            return View();
        }

        [PoliceStationAuthorization]
        public ActionResult PSProfile()
        {
            var ps = PoliceStationModel.GetPoliceStation(Session["username"].ToString());
            ps.Password = "xxxxxx";
            ps.ConfirmPassword = "xxxxxx";
            ps.Rolename = "PoliceStation";
            return View(ps);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [PoliceStationAuthorization]
        public JsonResult UpdatePoliceStation(PoliceStationModel pm)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    PoliceStationModel.UpdatePoliceStations(pm);

                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [PoliceStationAuthorization]
        public ActionResult ManageMissingPersons()
        {
            var mp = new MissingPersonModel
            {
                MPId = 0,
                MPName = "",
                Gender = "Male",
                Age = "",
                Weight = "",
                Height = "",
                Color = "",
                Complexion = "",
                Photo = "assets/img/noimage.jpg",
                Address = "",
                PinCode = "",
                ContactPersonName = "",
                ContactPersonNo = "",
                PSUsername = Session["username"].ToString(),
                Flag = false
            };
            return View(mp);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [PoliceStationAuthorization]
        public JsonResult SaveMissingPerson(MissingPersonModel mp, HttpPostedFileBase fd)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (mp.Flag == true)
                        mp.MPId = MissingPersonModel.GetMaxId();

                    if (fd != null)
                        mp.Photo = string.Format("assets/img/missingpersons/{0}.jpg", mp.MPId);

                    MissingPersonModel.Save(mp);

                    if (fd != null)
                        fd.SaveAs(Server.MapPath(Url.Content("~/" + mp.Photo)));

                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [PoliceStationAuthorization]
        public ActionResult ManageMostWantedPersons()
        {
            var mw = new MostWantedPersonModel
            {
                MWId = 0,
                MWName = "",
                MWLocation = "",
                MWOffences = "",
                MWDesc = "",
                MWPhoto = "assets/img/noimage.jpg",
                PSUsername = Session["username"].ToString()
            };
            return View(mw);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [PoliceStationAuthorization]
        public JsonResult SaveMostWantedPerson(MostWantedPersonModel mw, HttpPostedFileBase fd)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (mw.Flag == true)
                        mw.MWId = MostWantedPersonModel.GetMaxId();

                    if (fd != null)
                        mw.MWPhoto = string.Format("assets/img/mwpics/{0}.jpg", mw.MWId);

                    MostWantedPersonModel.Save(mw);

                    if (fd != null)
                        fd.SaveAs(Server.MapPath(Url.Content("~/" + mw.MWPhoto)));

                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [PoliceStationAuthorization]
        public JsonResult DeleteMostWantedPerson(int id)
        {
            object obj;
            try
            {
                MostWantedPersonModel.Delete(id);

                var filepath = string.Format("assets/img/mwpics/{0}.jpg", id);

                filepath = Server.MapPath("~/" + filepath);
                if (System.IO.File.Exists(filepath)) System.IO.File.Delete(filepath);

                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [PoliceStationAuthorization]
        public ActionResult PendingFIRs()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [PoliceStationAuthorization]
        public JsonResult FIRAction(FormCollection frm)
        {
            object obj;
            try
            {
                var firno = frm["hfFIRNo"];
                var casestatus = frm["rbCaseStatus"];
                var actionremarks = frm["txtActionRemarks"];

                if (actionremarks.Trim().Length != 0)
                {
                    FIRModel.UpdateFIR(firno, casestatus, actionremarks);

                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Plz Enter Action Remarks..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [PoliceStationAuthorization]
        public ActionResult FIRUnderProcess()
        {
            return View();
        }

        [PoliceStationAuthorization]
        public ActionResult CompletedFIRs()
        {
            return View();
        }


    }
}