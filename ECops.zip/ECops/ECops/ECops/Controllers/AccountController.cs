﻿using ECops.Filters;
using ECops.Models;
using ECops.Models.ViewModels;
using System;
using System.Web.Mvc;

namespace ECops.Controllers
{
    public class AccountController : Controller
    {
        // GET: Account
        public ActionResult SignIn()
        {
            UserModel user = new UserModel();
            user.Username = "";
            user.Password = "";
            user.Rolename = "Guest";
            return View(user);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult ValidateUser(UserModel user)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (UserModel.Validate(user))
                    {
                        Session["logstatus"] = true;
                        Session["username"] = user.Username;
                        string rolename = UserModel.GetRoleName(user.Username);

                        if (rolename == "PoliceStation")
                            Session["userdetail"] = PoliceStationModel.GetPoliceStationDetail(user.Username);
                        else if (rolename == "Citizen")
                            Session["userdetail"] = CitizenModel.GetCitizenDetail(user.Username);

                        Session["rolename"] = rolename;

                        obj = new
                        {
                            ResponseCode = 1,
                            RoleName = rolename
                        };
                    }
                    else
                    {
                        obj = new
                        {
                            ResponseCode = 0,
                            FailureText = "Invalid Username or Password..!!"
                        };
                    }
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation error occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [Authenticate]
        public ActionResult ChangePassword(ChangePasswordModel cpm)
        {
            cpm.Username = Session["username"].ToString();
            cpm.OldPassword = "";
            cpm.NewPassword = "";
            cpm.ConfirmPassword = "";
            return View(cpm);
        }

        [Authenticate]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult UpdatePassword(ChangePasswordModel cpm)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (UserModel.Validate(cpm.Username, cpm.OldPassword))
                    {
                        UserModel.UpdatePassword(cpm.Username, cpm.OldPassword, cpm.NewPassword);
                        obj = new
                        {
                            ResponseCode = 1,
                            ResponseText = "Success"
                        };
                    }
                    else
                    {
                        obj = new
                        {
                            ResponseCode = 0,
                            FailureText = "Invalid Old Password..!!"
                        };
                    }
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        public ActionResult SignOut()
        {
            Session.Abandon();
            Session["logstatus"] = false;
            Session["username"] = "guest";
            Session["rolename"] = "guest";
            Session["userdetail"] = "";
            return RedirectToAction("../Home");
        }

        
    }
}