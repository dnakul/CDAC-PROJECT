﻿using ECops.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ECops.Controllers.api
{
    public class CitizenController : ApiController
    {
        [HttpGet]
        public object GetCitizenList()
        {
            object obj;
            try
            {

                obj = new
                {
                    ResponseCode = 1,
                    CitizenList = CitizenModel.GetCitizens()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpPost]
        public object DeleteCitizen(dynamic data)
        {
            object obj;
            try
            {
                string cusername = data.CUsername;
                CitizenModel.DeleteCitizen(cusername);
                var imgPath = string.Format("~/assets/img/idfiles/{0}.jpg", cusername);
                imgPath = System.Web.Hosting.HostingEnvironment.MapPath(imgPath);
                if (System.IO.File.Exists(imgPath)) System.IO.File.Delete(imgPath);
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [HttpPost]
        public object MyFIRS(dynamic data)
        {
            object obj;
            try
            {
                string cusername = data.CUsername;
                obj = new
                {
                    ResponseCode = 1,
                    FIRList = FIRModel.GetUserWiseFIRS(cusername)
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteFIR(int id)
        {
            object obj;
            try
            {
                FIRModel.DeleteFIR(id);                
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpPost]
        public object MyComplaints(dynamic data)
        {
            object obj;
            try
            {
                string cusername = data.CUsername;
                obj = new
                {
                    ResponseCode = 1,
                    ComplaintList = ComplaintModel.GetUserWiseComplaints(cusername)
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteComplaint(int id)
        {
            object obj;
            try
            {
                ComplaintModel.DeleteComplaint(id);
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }
    }
}
