﻿using ECops.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ECops.Controllers.api
{
    public class HomeController : ApiController
    {
        public object GetStateCityList()
        {
            object obj;
            try
            {
                obj = new
                {
                    ResponseCode = 1,
                    StateList = StateModel.GetStates(),
                    CityList = CityModel.GetCities(),                    
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        public object GetStateCityPS() {
            object obj;
            try
            {
                obj = new
                {
                    ResponseCode = 1,
                    StateList = StateModel.GetStates(),
                    CityList=CityModel.GetCities(),
                    PSList=PoliceStationModel.GetPoliceStationsList()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        public object GetStateCityIL()
        {
            object obj;
            try
            {
                obj = new
                {
                    ResponseCode = 1,
                    StateList = StateModel.GetStates(),
                    CityList = CityModel.GetCities(),
                    ILList = ImportantLinksModel.GetImportantLinks()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        public object GetStateCityPSMP()
        {
            object obj;
            try
            {
                obj = new
                {
                    ResponseCode = 1,
                    StateList = StateModel.GetStates(),
                    CityList = CityModel.GetCities(),
                    PSList = PoliceStationModel.GetPoliceStationsList(),
                    MPList = MissingPersonModel.GetMissingPersons()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        public object GetStateCityPSMWP()
        {
            object obj;
            try
            {
                obj = new
                {
                    ResponseCode = 1,
                    StateList = StateModel.GetStates(),
                    CityList = CityModel.GetCities(),
                    PSList = PoliceStationModel.GetPoliceStationsList(),
                    MWPList = MostWantedPersonModel.GetMostWantedPersons()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }


    }
}
