﻿using ECops.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace ECops.Controllers.api
{
    public class AdminController : ApiController
    {
        [HttpGet]
        public object GetStateList()
        {
            object obj;
            try
            {                

                obj = new
                {
                    ResponseCode = 1,
                    StateList = StateModel.GetStates()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteState(int id)
        {
            object obj;
            try
            {
                StateModel.Delete(id);                
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpGet]
        public object GetStateCityList()
        {
            object obj;
            try
            {

                obj = new
                {
                    ResponseCode = 1,
                    StateList = StateModel.GetStates(),
                    CityList = CityModel.GetCities()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteCity(int id)
        {
            object obj;
            try
            {
                CityModel.Delete(id);
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [HttpGet]
        public object GetCaseTypeList()
        {
            object obj;
            try
            {

                obj = new
                {
                    ResponseCode = 1,
                    CaseTypeList = CaseTypeModel.GetCaseTypes()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteCaseType(int id)
        {
            object obj;
            try
            {
                CaseTypeModel.Delete(id);
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpGet]
        public object GetNewsList()
        {
            object obj;
            try
            {

                obj = new
                {
                    ResponseCode = 1,
                    NewsList = NewsModel.GetNews()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteNews(int id)
        {
            object obj;
            try
            {
                NewsModel.Delete(id);
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpGet]
        public object GetFAQList()
        {
            object obj;
            try
            {

                obj = new
                {
                    ResponseCode = 1,
                    FAQList = FAQModel.GetFAQs()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteFAQ(int id)
        {
            object obj;
            try
            {
                FAQModel.Delete(id);
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpGet]
        public object GetContactUsList()
        {
            object obj;
            try
            {

                obj = new
                {
                    ResponseCode = 1,
                    CUList = ContactUsModel.GetContactUsList()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteContactUs(int id)
        {
            object obj;
            try
            {
                ContactUsModel.Delete(id);
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpGet]
        public object GetFIRS()
        {
            object obj;
            try
            {
                obj = new
                {
                    ResponseCode = 1,
                    StateList = StateModel.GetStates(),
                    CityList = CityModel.GetCities(),
                    PSList = PoliceStationModel.GetPoliceStationsList(),
                    FIRList = FIRModel.GetFIRS()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpGet]
        public object GetComplaints()
        {
            object obj;
            try
            {                
                obj = new
                {
                    ResponseCode = 1,                    
                    StateList = StateModel.GetStates(),
                    CityList = CityModel.GetCities(),
                    PSList = PoliceStationModel.GetPoliceStationsList(),
                    ComplaintList = ComplaintModel.GetComplaints()
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

    }
}
