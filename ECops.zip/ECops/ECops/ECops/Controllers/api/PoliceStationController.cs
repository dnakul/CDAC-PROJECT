﻿using ECops.Models;
using System;
using System.Web.Hosting;
using System.Web.Http;

namespace ECops.Controllers.api
{
    public class PoliceStationController : ApiController
    {
        [HttpPost]
        public object GetMissingPersonsList(dynamic data)
        {
            object obj;
            try
            {
                string psusername = data.PSUsername;

                obj = new
                {
                    ResponseCode = 1,                    
                    MPList = MissingPersonModel.GetMissingPersons(psusername)
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]        
        public object DeleteMissingPerson(int id)
        {
            object obj;
            try
            {
                MissingPersonModel.Delete(id);

                var filepath = string.Format("assets/img/missingpersons/{0}.jpg", id);

                filepath = HostingEnvironment.MapPath("~/" + filepath);
                if (System.IO.File.Exists(filepath)) System.IO.File.Delete(filepath);

                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [HttpPost]
        public object GetMostWantedPersonsList(dynamic data)
        {
            object obj;
            try
            {
                string psusername = data.PSUsername;

                obj = new
                {
                    ResponseCode = 1,
                    MWList = MostWantedPersonModel.GetMostWantedPersons(psusername)
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }

        [HttpDelete]
        public object DeleteMostWantedPerson(int id)
        {
            object obj;
            try
            {
                MostWantedPersonModel.Delete(id);

                var filepath = string.Format("assets/img/mwpics/{0}.jpg", id);

                filepath = HostingEnvironment.MapPath("~/" + filepath);
                if (System.IO.File.Exists(filepath)) System.IO.File.Delete(filepath);

                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpPost]
        public object DeletePoliceStation(dynamic data)
        {
            object obj;
            try
            {
                string psusername = data.PSUsername;
                PoliceStationModel.DeletePoliceStation(psusername);
                
                obj = new
                {
                    ResponseCode = 1,
                    ResponseText = "Success"
                };

            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [HttpPost]
        public object GetFIRS(dynamic data)
        {
            object obj;
            try
            {
                string psusername = data.PSUsername;                
                obj = new
                {
                    ResponseCode = 1,
                    FIRList = FIRModel.GetPoliceStationWiseFIRS(psusername)
                };
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = "Error: " + ex.ToString()
                };
            }
            return obj;
        }
       
    }
}
