﻿using ECops.Filters;
using ECops.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ECops.Controllers
{
    public class CitizenController : Controller
    {
        // GET: Citizen
        [CitizenAuthorization]
        public ActionResult Index()
        {
            return View();
        }

        [CitizenAuthorization]
        public ActionResult MyProfile()
        {
            var c = CitizenModel.GetCitizen(Session["username"].ToString());
            c.Password = "xxxxxx";
            c.ConfirmPassword = "xxxxxx";
            c.Rolename = "Citizen";
            return View(c);
        }

        public ActionResult NewCitizen()
        {
            var c = new CitizenModel
            {
                CUsername = "",
                Password = "",
                ConfirmPassword = "",
                Rolename = "Citizen",
                Name = "",
                Gender = "Male",
                DOB = DateTime.Now.AddYears(-18),
                StateId = 0,
                CityId = 0,
                Address = "",
                PinCode = "",
                ContactNo = "",
                Email = "",
                IdProof = "assets/img/noimage.jpg",
                RegDate = DateTime.Now
            };
            return View(c);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public JsonResult SaveNewCitizen(CitizenModel cm,HttpPostedFileBase fd)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (fd != null)
                        cm.IdProof = string.Format("assets/img/idfiles/{0}.jpg", cm.CUsername);

                    CitizenModel.NewCitizen(cm);

                    if (fd != null)
                        fd.SaveAs(Server.MapPath(Url.Content("~/" + cm.IdProof)));


                    Session["logstatus"] = true;
                    Session["username"] = cm.CUsername;                   
                    Session["userdetail"] = CitizenModel.GetCitizenDetail(cm.CUsername);

                    Session["rolename"] = "Citizen";

                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        [CitizenAuthorization]
        public JsonResult UpdateCitizen(CitizenModel cm, HttpPostedFileBase fd)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (fd != null)
                        cm.IdProof = string.Format("assets/img/idfiles/{0}.jpg", cm.CUsername);

                    CitizenModel.UpdateCitizen(cm);

                    if (fd != null)
                        fd.SaveAs(Server.MapPath(Url.Content("~/" + cm.IdProof)));


                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [CitizenAuthorization]
        public ActionResult LodgeFIR()
        {
            var f = new FIRModel
            {
                FIRNo = FIRModel.GetMaxId(),
                FIRDate = DateTime.Now,
                CUsername = Session["username"].ToString(),
                PSUsername = "0",                
                VictimName = "",
                VictimFatherName = "",
                VictimGender = "Male",
                VictimDOB = DateTime.Now.AddYears(-18),
                StateId = 0,
                CityId = 0,
                VictimAddress = "",
                VictimPinCode = "",
                LstCaseTypes=CaseTypeModel.GetCaseTypeList(),
                CaseTypeId=0,
                CaseDate=DateTime.Now,
                CaseTitle = "",
                CaseDesc="",
                FIRStatus="P",
                ActionTaken="FIR Pending, No Action taken...!!"
            };
            return View(f);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [CitizenAuthorization]
        public JsonResult SaveFIR(FIRModel fm)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    FIRModel.LodgeFIR(fm);

                    int firno = fm.FIRNo;
                    string PSName = (PoliceStationModel.GetPoliceStationDetail(fm.PSUsername)).Name;
                    
                    obj = new
                    {
                        ResponseCode = 1,
                        FIRNo= firno,
                        PoliceStation=PSName,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [CitizenAuthorization]
        public ActionResult MyFIRS()
        {           
            return View();
        }

        [CitizenAuthorization]
        public ActionResult LodgeComplaint()
        {
            var lst = new List<SelectListItem>();

            var li1 = new SelectListItem();
            li1.Text = "Complaint";
            li1.Value = "Complaint";
            
            var li2 = new SelectListItem();
            li2.Text = "Query";
            li2.Value = "Query";           

            var li3 = new SelectListItem();
            li3.Text = "Suggestion";
            li3.Value = "Suggestion";

            lst.Add(li1);
            lst.Add(li2);
            lst.Add(li3);

            var c = new ComplaintModel
            {
                ComplaintNo = ComplaintModel.GetMaxId(),
                LstComplaintTypes=lst,
                ComplaintType="",
                ComplaintDetail="",
                ComplaintDate = DateTime.Now,
                CUsername = Session["username"].ToString(),
                StateId = 0,
                CityId = 0,
                PSUsername = "0",
                Status = "P",
                ActionTaken = "Complaint Pending, No Action taken...!!"
            };
            return View(c);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        [CitizenAuthorization]
        public JsonResult SaveComplaint(ComplaintModel cm)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    ComplaintModel.LodgeComplaint(cm);

                    int complaintno = cm.ComplaintNo;
                    
                    obj = new
                    {
                        ResponseCode = 1,
                        ComplaintNo = complaintno,                        
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [CitizenAuthorization]
        public ActionResult MyComplaints()
        {
            return View();
        }


    }
}