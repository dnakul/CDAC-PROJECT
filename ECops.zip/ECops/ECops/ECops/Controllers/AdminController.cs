﻿using ECops.Filters;
using ECops.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace ECops.Controllers
{
    public class AdminController : Controller
    {
        // GET: Admin
        [AdminAuthorization]
        public ActionResult Index()
        {
            return View();
        }

        [AdminAuthorization]
        public ActionResult PoliceStationRegistration()
        {
            var ps = new PoliceStationModel {
                PSUsername = "",
                Password = "",
                ConfirmPassword = "",
                Rolename = "PoliceStation",
                Name = "",                
                StateId = 0,
                CityId = 0,
                Address = "xxxxxx",
                PinCode = "xxxxxx",
                ContactNos = "",
                Email = "",
                PSInchargeName = "xxxxxx",
                InchargeGender = "Male",
                InchargeContactNo="xxxxxxxxxx",
                RegDate = DateTime.Now
            };
            return View(ps);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        [AdminAuthorization]
        public JsonResult SavePoliceStation(PoliceStationModel pm)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    PoliceStationModel.NewPoliceStation(pm);
                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [AdminAuthorization]
        public ActionResult ManageStates()
        {
            var s = new StateModel
            {
                StateId=0,
                StateName="",
                Flag=false
            };
            return View(s);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        [AdminAuthorization]
        public JsonResult SaveState(StateModel s)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (s.Flag == true)
                        s.StateId = StateModel.GetMaxId();

                    StateModel.Save(s);
                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [AdminAuthorization]
        public ActionResult ManageCities()
        {
            var c = new CityModel
            {
                CityId = 0,
                CityName = "",
                StateId=0,
                Flag = false
            };
            return View(c);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        [AdminAuthorization]
        public JsonResult SaveCity(CityModel c)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (c.Flag == true)
                        c.CityId = CityModel.GetMaxId();

                    CityModel.Save(c);
                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [AdminAuthorization]
        public ActionResult ManageCaseTypes()
        {
            var c = new CaseTypeModel
            {
                CaseTypeId = 0,
                CaseTypeDesc = "",
                Flag = false
            };
            return View(c);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        [AdminAuthorization]
        public JsonResult SaveCaseType(CaseTypeModel c)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (c.Flag == true)
                        c.CaseTypeId = CaseTypeModel.GetMaxId();

                    CaseTypeModel.Save(c);
                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }



        [AdminAuthorization]
        public ActionResult ManageNews()
        {
            var n = new NewsModel
            {
                NewsId = 0,
                NewsContent = "",
                NewsDate = DateTime.Now,
                Flag = false
            };
            return View(n);
        }     


        [HttpPost]
        [ValidateAntiForgeryToken]
        [AdminAuthorization]
        public JsonResult SaveNews(NewsModel n)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (n.Flag == true)
                        n.NewsId = NewsModel.GetMaxId();

                    NewsModel.Save(n);
                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }


        [AdminAuthorization]
        public ActionResult ManageFAQs()
        {
            var f = new FAQModel
            {
                FAQId = 0,
                Question = "",
                Answer = "",
                Flag = false
            };
            return View(f);
        }



        [HttpPost]
        [ValidateAntiForgeryToken]
        [AdminAuthorization]
        public JsonResult SaveFAQ(FAQModel f)
        {
            object obj;
            try
            {
                if (ModelState.IsValid)
                {
                    if (f.Flag == true)
                        f.FAQId = FAQModel.GetMaxId();

                    FAQModel.Save(f);
                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Validation Error Occurred..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }

        [AdminAuthorization]
        public ActionResult ListOfUsers()
        {            
            return View();
        }

        [AdminAuthorization]
        public ActionResult ContactUsList()
        {
            return View();
        }

        [AdminAuthorization]
        public ActionResult ManagePoliceStation()
        {
            return View();
        }

        [AdminAuthorization]
        public ActionResult PoliceStationWiseFIR()
        {
            return View();
        }


        [AdminAuthorization]
        public ActionResult PendingUserGrievances()
        {
            return View();
        }

        [AdminAuthorization]
        public ActionResult UnderProcessUserGrievances()
        {
            return View();
        }

        [AdminAuthorization]
        public ActionResult CompletedUserGrievances()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [AdminAuthorization]
        public JsonResult ComplaintAction(FormCollection frm)
        {
            object obj;
            try
            {
                var complaintno = frm["hfComplaintNo"];
                var casestatus = frm["rbStatus"];
                var actionremarks = frm["txtActionRemarks"];

                if (actionremarks.Trim().Length != 0)
                {
                    ComplaintModel.UpdateComplaint(complaintno, casestatus, actionremarks);

                    obj = new
                    {
                        ResponseCode = 1,
                        ResponseText = "Success"
                    };
                }
                else
                {
                    obj = new
                    {
                        ResponseCode = 0,
                        FailureText = "Plz Enter Action Remarks..!!"
                    };
                }
            }
            catch (Exception ex)
            {
                obj = new
                {
                    ResponseCode = 0,
                    FailureText = ex.ToString()
                };
            }
            return Json(obj);
        }



    }
}