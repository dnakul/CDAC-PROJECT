﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using System.Web.Security;
using System.Web.SessionState;
using System.Web.Http;
using ECops.MessageHandlers;

namespace ECops
{
    public class Global : HttpApplication
    {
        void Application_Start(object sender, EventArgs e)
        {
            // Code that runs on application startup
            AreaRegistration.RegisterAllAreas();
            GlobalConfiguration.Configure(WebApiConfig.Register);
            GlobalConfiguration.Configuration.MessageHandlers.Add(new APIKeyMessageHandler());
            RouteConfig.RegisterRoutes(RouteTable.Routes);            
        }

        void Session_Start(object sender, EventArgs e)
        {
            Session.Add("logstatus", false);
            Session.Add("username", "guest");
            Session.Add("rolename", "guest");
            Session.Add("userdetail", "");
        }
    }
}